package com.slloan.constants;

/**
 * 验证码&登录常量
 * @author Administrator
 *
 */
public class  CaptchaConstants {
	//登录
	public final static String LOGIN = "checkLogin";
	
	public final static String VERIFICATIONCODE = "verificationcode";
}

