package com.slloan.entity;

public class startentity {
	
	
}
