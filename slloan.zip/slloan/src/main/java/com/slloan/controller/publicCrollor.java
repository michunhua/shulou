package com.slloan.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.slloan.service.inter.ApplyForLoanInformationService;

@Controller(value="publicCoroller")
@RequestMapping("/loan")
public class publicCrollor {
	
	
}
